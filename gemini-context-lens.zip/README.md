# ContextLens — Gemini AI Contextual Definition & Translation Extension

> Production-ready Chrome Extension (Manifest V3) that provides instant, contextual definitions and translations powered by the Google Gemini API directly in a floating tooltip near your cursor.

---

## ✨ Features

- **Context-Aware Definitions**: Captures both the highlighted word/phrase and its exact surrounding paragraph, prompting Gemini to interpret the word's specific meaning in that context (e.g. polysemous words like *"tender"*, *"terminal"*, or *"strike"*).
- **Strict Minimalist Output**: Guided by a system prompt enforcing concise, direct 1–2 sentence definitions (under 35 words) with no filler or preambles.
- **Isolated Shadow DOM Architecture**: Uses an open Shadow Root to inject the floating tooltip, ensuring 100% style isolation and immunity from host website CSS conflicts.
- **No Sidebars**: Pure minimalist floating tooltip positioned directly above/below the cursor selection with collision-aware screen boundary repositioning.
- **Dual Trigger Modes**:
  - **Sparkle Trigger Pill (Recommended Default)**: Non-intrusive floating `✨ Define` icon appears on highlight. Click to view definition without interfering with standard text selection/copying.
  - **Instant Mode**: Automatically fetches and opens definition tooltip immediately when text is highlighted.
- **Audio Pronunciation & Copy**: Built-in speech synthesis to listen to highlighted words, one-click definition copying with visual feedback, and an expandable "Paragraph Context" preview.
- **Service Worker Security**: API calls are routed through the background service worker (`background.js`), bypassing web page Content Security Policies (CSP) and preventing API key leakage into page DOM.
- **Model Flexibility**: Choose between `gemini-1.5-flash` (fastest), `gemini-2.0-flash`, or `gemini-1.5-pro` directly in the extension popup.

---

## 📁 Project Structure

```
gemini-context-lens/
├── manifest.json         # Manifest V3 specification
├── background.js        # Background service worker (Gemini API calls, caching)
├── content.js           # Selection capture, context extraction, Shadow DOM UI
├── content.css          # Isolated glassmorphism styling for floating tooltip
├── popup.html           # Quick configuration popup
├── popup.css            # Popup styling
├── popup.js             # API key management, connection testing & settings
├── options.html         # Full settings & options page
├── options.css          # Options page styling
├── options.js           # Options page logic
├── test_page.html       # Interactive test bench with sample contextual words
└── icons/               # Production PNG icons
    ├── icon16.png
    ├── icon32.png
    ├── icon48.png
    └── icon128.png
```

---

## 🚀 Installation Guide

### Option 1: Load Unpacked (Recommended for Development / Immediate Use)
1. Open Google Chrome.
2. Navigate to `chrome://extensions/` in the address bar.
3. Toggle on **Developer mode** in the top right corner.
4. Click **Load unpacked** in the top left corner.
5. Select the folder:
   ```
   c:\Users\Hp\.antigravity-ide\gemini-context-lens
   ```
6. The **ContextLens** extension will now appear in your toolbar!

### Option 2: From the Packaged `.zip`
1. Extract `gemini-context-lens.zip` to a folder.
2. Follow steps 1–4 above and select the extracted folder.

---

## 🔑 Setting Up Your Gemini API Key

1. Click the **ContextLens** icon in your Chrome toolbar (pin it for quick access).
2. If you don't have a Gemini API key yet, click the **Get Free Key ↗** link or visit [Google AI Studio](https://aistudio.google.com/app/apikey).
3. Paste your API key into the input field.
4. Click **Test Key** to verify your connection.
5. Click **Save Settings**.

---

## 🧪 Testing the Extension

1. Open `test_page.html` in Chrome (e.g., drag and drop the file into Chrome or open `file:///c:/Users/Hp/.antigravity-ide/gemini-context-lens/test_page.html`).
2. Highlight the word **"tender"** in *Sample 1 (Finance)* -> Gemini will define it as an offer or presentation of a buyout bid.
3. Highlight **"tender"** in *Sample 2 (Culinary)* -> Gemini will define it as soft and easily chewed meat.
4. Highlight the foreign phrase **"fait accompli"** -> Gemini will return its translation and diplomatic context.
