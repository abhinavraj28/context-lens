/**
 * ContextLens - Content Script
 * Captures highlighted text + surrounding paragraph context
 * Displays minimalist floating tooltip using encapsulated Shadow DOM
 */

(function () {
  // Prevent duplicate injection
  if (window.__CONTEXT_LENS_INJECTED__) return;
  window.__CONTEXT_LENS_INJECTED__ = true;

  let shadowRoot = null;
  let hostElement = null;
  let tooltipElement = null;
  let triggerBubble = null;

  let currentSelectionTerm = "";
  let currentSelectionContext = "";
  let currentSelectionRect = null;
  let isTooltipOpen = false;
  let isTriggerOpen = false;

  // Settings
  let triggerMode = "button"; // 'button' (sparkle pill) or 'instant' (auto-fetch)

  // Load preferences
  function loadPreferences() {
    if (chrome && chrome.storage && chrome.storage.sync) {
      chrome.storage.sync.get(["triggerMode"], (res) => {
        if (res.triggerMode) triggerMode = res.triggerMode;
      });
    }
  }
  loadPreferences();

  // Listen for preference changes from popup
  if (chrome && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "sync" && changes.triggerMode) {
        triggerMode = changes.triggerMode.newValue;
      }
    });
  }

  /**
   * Initialize Shadow DOM host
   */
  function initShadowDOM() {
    if (hostElement) return;

    hostElement = document.createElement("div");
    hostElement.id = "context-lens-root";
    (document.body || document.documentElement).appendChild(hostElement);

    shadowRoot = hostElement.attachShadow({ mode: "open" });

    // Inject styles
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = chrome.runtime.getURL("content.css");
    shadowRoot.appendChild(link);

    // SVG Gradient definitions
    const svgDefs = document.createElement("div");
    svgDefs.innerHTML = `
      <svg width="0" height="0" style="position:absolute; display:none;">
        <defs>
          <linearGradient id="cl-gemini-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#818cf8" />
            <stop offset="100%" stop-color="#c084fc" />
          </linearGradient>
        </defs>
      </svg>
    `;
    shadowRoot.appendChild(svgDefs);

    // Build Floating Trigger Bubble
    triggerBubble = document.createElement("div");
    triggerBubble.className = "cl-trigger-bubble";
    triggerBubble.innerHTML = `
      <svg class="cl-trigger-icon" viewBox="0 0 24 24">
        <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" fill="url(#cl-gemini-gradient)" />
      </svg>
      <span class="cl-trigger-label">Define</span>
    `;
    shadowRoot.appendChild(triggerBubble);

    triggerBubble.addEventListener("mousedown", (e) => {
      e.preventDefault();
      e.stopPropagation();
      openTooltip();
    });

    // Build Floating Tooltip Container
    tooltipElement = document.createElement("div");
    tooltipElement.className = "cl-tooltip";
    shadowRoot.appendChild(tooltipElement);

    // Prevent clicks inside tooltip from closing it
    tooltipElement.addEventListener("mousedown", (e) => {
      e.stopPropagation();
    });
  }

  /**
   * Extract surrounding paragraph context for a selection
   */
  function extractSurroundingParagraph(selection) {
    if (!selection || !selection.rangeCount) return "";
    const range = selection.getRangeAt(0);

    let container = range.commonAncestorContainer;
    if (container.nodeType === Node.TEXT_NODE) {
      container = container.parentElement;
    }
    if (!container) return selection.toString().trim();

    const blockTags = new Set([
      "P", "ARTICLE", "SECTION", "BLOCKQUOTE", "LI", "DD", "DT",
      "H1", "H2", "H3", "H4", "H5", "H6", "DIV", "MAIN", "TD", "TH"
    ]);

    let curr = container;
    let candidate = null;

    while (curr && curr !== document.body && curr !== document.documentElement) {
      const tag = curr.tagName ? curr.tagName.toUpperCase() : "";
      if (blockTags.has(tag)) {
        const text = (curr.innerText || curr.textContent || "").trim();
        if (text.length >= 15) {
          candidate = curr;
          // Ideal paragraph container
          if (tag === "P" || tag === "BLOCKQUOTE" || tag === "LI") {
            break;
          }
        }
      }
      curr = curr.parentElement;
    }

    const fullText = candidate ? (candidate.innerText || candidate.textContent || "") : (container.innerText || container.textContent || "");
    const cleaned = fullText.replace(/\s+/g, " ").trim();

    // If context is huge (e.g. giant div), extract a focused window around the highlighted term
    const term = selection.toString().trim();
    if (cleaned.length > 900 && term) {
      const idx = cleaned.toLowerCase().indexOf(term.toLowerCase());
      if (idx !== -1) {
        const start = Math.max(0, idx - 300);
        const end = Math.min(cleaned.length, idx + term.length + 300);
        let excerpt = cleaned.substring(start, end).trim();
        if (start > 0) excerpt = "..." + excerpt;
        if (end < cleaned.length) excerpt = excerpt + "...";
        return excerpt;
      }
    }

    return cleaned || term;
  }

  /**
   * Handle mouseup / selection change
   */
  function handleSelection() {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed) {
      if (!isTooltipOpen) {
        hideTriggerBubble();
      }
      return;
    }

    const text = selection.toString().trim();
    // Filter out invalid/empty/extremely long highlights
    if (!text || text.length < 2 || text.length > 250) {
      if (!isTooltipOpen) hideTriggerBubble();
      return;
    }

    // Ensure selection is not inside our own shadow DOM
    if (shadowRoot && shadowRoot.contains(selection.anchorNode)) {
      return;
    }

    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return;

    currentSelectionTerm = text;
    currentSelectionContext = extractSurroundingParagraph(selection);
    currentSelectionRect = rect;

    initShadowDOM();

    if (triggerMode === "instant") {
      openTooltip();
    } else {
      showTriggerBubble(rect);
    }
  }

  /**
   * Position & display the trigger bubble
   */
  function showTriggerBubble(rect) {
    if (!triggerBubble) return;

    const bubbleWidth = 72;
    const bubbleHeight = 28;

    let left = rect.left + rect.width / 2 - bubbleWidth / 2;
    // Boundary check X
    left = Math.max(10, Math.min(left, window.innerWidth - bubbleWidth - 10));

    // Place above selection if room, otherwise below
    let top = rect.top - bubbleHeight - 6;
    if (top < 10) {
      top = rect.bottom + 6;
    }

    triggerBubble.style.left = `${Math.round(left)}px`;
    triggerBubble.style.top = `${Math.round(top)}px`;
    triggerBubble.classList.add("cl-visible");
    isTriggerOpen = true;
  }

  function hideTriggerBubble() {
    if (triggerBubble) {
      triggerBubble.classList.remove("cl-visible");
      isTriggerOpen = false;
    }
  }

  /**
   * Position the tooltip near selection
   */
  function positionTooltip(rect) {
    if (!tooltipElement) return;

    const tooltipWidth = 330;
    const estHeight = 160;

    let left = rect.left + rect.width / 2 - tooltipWidth / 2;
    left = Math.max(12, Math.min(left, window.innerWidth - tooltipWidth - 12));

    // Prefer placing directly below or above selection
    let top = rect.bottom + 8;
    // If overflowing bottom of viewport, flip above
    if (top + estHeight > window.innerHeight - 12) {
      const topAbove = rect.top - estHeight - 8;
      if (topAbove > 12) {
        top = topAbove;
      }
    }

    tooltipElement.style.left = `${Math.round(left)}px`;
    tooltipElement.style.top = `${Math.round(top)}px`;
  }

  /**
   * Render loading skeleton state in tooltip
   */
  function renderLoading(term) {
    const escapedTerm = escapeHTML(term);
    tooltipElement.innerHTML = `
      <div class="cl-header">
        <div class="cl-header-left">
          <svg class="cl-sparkle-icon" viewBox="0 0 24 24" fill="none">
            <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" fill="url(#cl-gemini-gradient)"/>
          </svg>
          <span class="cl-term-badge" title="${escapedTerm}">${escapedTerm}</span>
        </div>
        <div class="cl-header-actions">
          <button class="cl-action-btn" id="cl-close-btn" title="Close">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
      </div>

      <div class="cl-body">
        <div class="cl-skeleton-wrap">
          <div class="cl-skeleton-line"></div>
          <div class="cl-skeleton-line short"></div>
          <div class="cl-loading-label">
            <span>Interpreting context with Gemini...</span>
          </div>
        </div>
      </div>

      <div class="cl-footer">
        <span class="cl-model-tag">Gemini AI</span>
        <span class="cl-footer-badge">Context-aware</span>
      </div>
    `;

    shadowRoot.getElementById("cl-close-btn").addEventListener("click", closeTooltip);
  }

  /**
   * Render definition result
   */
  function renderResult(term, definition, model, cached) {
    const escapedTerm = escapeHTML(term);
    const escapedDef = escapeHTML(definition);

    // Format highlighted context preview
    let contextPreviewHTML = "";
    if (currentSelectionContext && currentSelectionContext !== term) {
      const reg = new RegExp(`(${escapeRegex(term)})`, "gi");
      const highlightedSnippet = escapeHTML(currentSelectionContext).replace(reg, "<mark>$1</mark>");
      contextPreviewHTML = `
        <div class="cl-context-wrap">
          <button class="cl-context-toggle" id="cl-toggle-context">
            <span>Paragraph Context</span>
            <span id="cl-context-chevron">▼</span>
          </button>
          <div class="cl-context-preview" id="cl-context-box">
            ${highlightedSnippet}
          </div>
        </div>
      `;
    }

    tooltipElement.innerHTML = `
      <div class="cl-header">
        <div class="cl-header-left">
          <svg class="cl-sparkle-icon" viewBox="0 0 24 24" fill="none">
            <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" fill="url(#cl-gemini-gradient)"/>
          </svg>
          <span class="cl-term-badge" title="${escapedTerm}">${escapedTerm}</span>
        </div>
        <div class="cl-header-actions">
          <button class="cl-action-btn" id="cl-speak-btn" title="Pronounce">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
              <path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path>
              <path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path>
            </svg>
          </button>
          <button class="cl-action-btn" id="cl-copy-btn" title="Copy Definition">
            <svg id="cl-copy-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
          </button>
          <button class="cl-action-btn" id="cl-close-btn" title="Close">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
      </div>

      <div class="cl-body">
        <p class="cl-definition-text">${escapedDef}</p>
        ${contextPreviewHTML}
      </div>

      <div class="cl-footer">
        <span class="cl-model-tag">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z"/>
          </svg>
          ${escapeHTML(model || "gemini-1.5-flash")}
        </span>
        <span class="cl-footer-badge">${cached ? "Cached" : "Contextualized"}</span>
      </div>
    `;

    // Hook listeners
    shadowRoot.getElementById("cl-close-btn").addEventListener("click", closeTooltip);

    const copyBtn = shadowRoot.getElementById("cl-copy-btn");
    copyBtn.addEventListener("click", () => {
      navigator.clipboard.writeText(definition).then(() => {
        copyBtn.innerHTML = `
          <svg viewBox="0 0 24 24" fill="none" stroke="#4ade80" stroke-width="2.5">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
        `;
        setTimeout(() => {
          copyBtn.innerHTML = `
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
          `;
        }, 1500);
      });
    });

    const speakBtn = shadowRoot.getElementById("cl-speak-btn");
    speakBtn.addEventListener("click", () => {
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(term);
        utterance.rate = 0.95;
        window.speechSynthesis.speak(utterance);
      }
    });

    const toggleContextBtn = shadowRoot.getElementById("cl-toggle-context");
    if (toggleContextBtn) {
      toggleContextBtn.addEventListener("click", () => {
        const previewBox = shadowRoot.getElementById("cl-context-box");
        const chevron = shadowRoot.getElementById("cl-context-chevron");
        const isOpen = previewBox.classList.toggle("cl-open");
        chevron.textContent = isOpen ? "▲" : "▼";
      });
    }
  }

  /**
   * Render error state
   */
  function renderError(term, errorType, message) {
    const escapedTerm = escapeHTML(term);
    const escapedMsg = escapeHTML(message);

    const isApiKeyError = errorType === "NO_API_KEY" || errorType === "INVALID_KEY";

    tooltipElement.innerHTML = `
      <div class="cl-header">
        <div class="cl-header-left">
          <svg class="cl-sparkle-icon" viewBox="0 0 24 24" fill="none">
            <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" fill="#ef4444"/>
          </svg>
          <span class="cl-term-badge" title="${escapedTerm}">${escapedTerm}</span>
        </div>
        <div class="cl-header-actions">
          <button class="cl-action-btn" id="cl-close-btn" title="Close">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
      </div>

      <div class="cl-body">
        <div class="cl-error-wrap">
          <div class="cl-error-title">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10"></circle>
              <line x1="12" y1="8" x2="12" y2="12"></line>
              <line x1="12" y1="16" x2="12.01" y2="16"></line>
            </svg>
            ${isApiKeyError ? "Gemini API Key Required" : "Unable to Fetch Definition"}
          </div>
          <p class="cl-error-desc">${escapedMsg}</p>
          ${
            isApiKeyError
              ? `<button class="cl-error-btn" id="cl-open-settings-btn">Open Settings</button>`
              : ""
          }
        </div>
      </div>

      <div class="cl-footer">
        <span class="cl-model-tag" style="color: #ef4444;">ContextLens</span>
        <span class="cl-footer-badge">Error</span>
      </div>
    `;

    shadowRoot.getElementById("cl-close-btn").addEventListener("click", closeTooltip);

    const openSettingsBtn = shadowRoot.getElementById("cl-open-settings-btn");
    if (openSettingsBtn) {
      openSettingsBtn.addEventListener("click", () => {
        chrome.runtime.sendMessage({ action: "OPEN_SETTINGS" });
      });
    }
  }

  /**
   * Open tooltip and fetch definition
   */
  function openTooltip() {
    if (!currentSelectionTerm || !currentSelectionRect) return;

    hideTriggerBubble();
    initShadowDOM();

    positionTooltip(currentSelectionRect);
    renderLoading(currentSelectionTerm);

    tooltipElement.classList.add("cl-visible");
    isTooltipOpen = true;

    // Send payload to background service worker
    chrome.runtime.sendMessage(
      {
        action: "GET_DEFINITION",
        payload: {
          term: currentSelectionTerm,
          context: currentSelectionContext
        }
      },
      (response) => {
        if (!isTooltipOpen) return; // closed while pending

        if (!response) {
          renderError(
            currentSelectionTerm,
            "COMM_ERROR",
            "Could not communicate with the extension background worker."
          );
          return;
        }

        if (response.success) {
          renderResult(
            currentSelectionTerm,
            response.text,
            response.model,
            response.cached
          );
        } else {
          renderError(
            currentSelectionTerm,
            response.errorType,
            response.message
          );
        }
      }
    );
  }

  function closeTooltip() {
    if (tooltipElement) {
      tooltipElement.classList.remove("cl-visible");
    }
    isTooltipOpen = false;
  }

  // Escape HTML helper
  function escapeHTML(str) {
    if (!str) return "";
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function escapeRegex(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  // Mouse & Keyboard Event Listeners
  document.addEventListener("mouseup", (e) => {
    // If clicking inside our shadow root, ignore
    if (shadowRoot && shadowRoot.contains(e.target)) return;

    setTimeout(handleSelection, 10);
  });

  document.addEventListener("keyup", (e) => {
    if (e.key === "Escape") {
      closeTooltip();
      hideTriggerBubble();
      return;
    }
    setTimeout(handleSelection, 10);
  });

  // Clicking outside tooltip or trigger bubble closes them
  document.addEventListener("mousedown", (e) => {
    if (shadowRoot && shadowRoot.contains(e.target)) return;

    if (isTriggerOpen) {
      hideTriggerBubble();
    }
    if (isTooltipOpen) {
      closeTooltip();
    }
  });

  // Window resize repositions or dismisses smoothly
  window.addEventListener("resize", () => {
    if (isTooltipOpen && currentSelectionRect) {
      positionTooltip(currentSelectionRect);
    }
  });
})();
