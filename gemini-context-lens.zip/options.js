/**
 * ContextLens - Options Page Logic
 */

document.addEventListener("DOMContentLoaded", () => {
  const apiKeyInput = document.getElementById("opt-api-key");
  const toggleKeyBtn = document.getElementById("opt-toggle-key");
  const modelSelect = document.getElementById("opt-model-select");
  const triggerModeSelect = document.getElementById("opt-trigger-mode");
  const testBtn = document.getElementById("opt-test-btn");
  const spinner = document.getElementById("opt-spinner");
  const testMsg = document.getElementById("opt-test-msg");
  const saveBtn = document.getElementById("opt-save-btn");
  const saveStatus = document.getElementById("opt-save-status");

  // Load existing settings
  chrome.storage.sync.get(["geminiApiKey", "selectedModel", "triggerMode"], (data) => {
    if (data.geminiApiKey) apiKeyInput.value = data.geminiApiKey;
    if (data.selectedModel) modelSelect.value = data.selectedModel;
    if (data.triggerMode) triggerModeSelect.value = data.triggerMode;
  });

  // Toggle key visibility
  toggleKeyBtn.addEventListener("click", () => {
    if (apiKeyInput.type === "password") {
      apiKeyInput.type = "text";
      toggleKeyBtn.textContent = "Hide";
    } else {
      apiKeyInput.type = "password";
      toggleKeyBtn.textContent = "Show";
    }
  });

  // Test key
  testBtn.addEventListener("click", () => {
    const key = apiKeyInput.value.trim();
    const model = modelSelect.value;

    if (!key) {
      testMsg.textContent = "Please enter an API key to test.";
      testMsg.className = "inline-msg error";
      return;
    }

    spinner.classList.add("show");
    testBtn.disabled = true;
    testMsg.textContent = "";

    chrome.runtime.sendMessage(
      {
        action: "TEST_API_KEY",
        payload: {
          apiKey: key,
          model: model
        }
      },
      (res) => {
        spinner.classList.remove("show");
        testBtn.disabled = false;

        if (res && res.success) {
          testMsg.textContent = "✓ Connected to Gemini API successfully!";
          testMsg.className = "inline-msg success";
        } else {
          testMsg.textContent = (res && res.message) || "Validation failed.";
          testMsg.className = "inline-msg error";
        }
      }
    );
  });

  // Save settings
  saveBtn.addEventListener("click", () => {
    const key = apiKeyInput.value.trim();
    const model = modelSelect.value;
    const triggerMode = triggerModeSelect.value;

    chrome.storage.sync.set(
      {
        geminiApiKey: key,
        selectedModel: model,
        triggerMode: triggerMode
      },
      () => {
        saveStatus.textContent = "✓ Preferences saved successfully!";
        saveBtn.style.opacity = "0.8";

        setTimeout(() => {
          saveStatus.textContent = "";
          saveBtn.style.opacity = "1";
        }, 2500);
      }
    );
  });
});
