/**
 * ContextLens - Popup Logic
 */

document.addEventListener("DOMContentLoaded", () => {
  const apiKeyInput = document.getElementById("api-key");
  const toggleKeyBtn = document.getElementById("toggle-key-visibility");
  const modelSelect = document.getElementById("model-select");
  const triggerModeSelect = document.getElementById("trigger-mode");
  const btnTest = document.getElementById("btn-test");
  const btnSave = document.getElementById("btn-save");
  const testSpinner = document.getElementById("test-spinner");
  const testResult = document.getElementById("test-result");
  const statusIndicator = document.getElementById("status-indicator");
  const statusBadgeText = document.getElementById("status-badge-text");

  // Load saved settings
  chrome.storage.sync.get(["geminiApiKey", "selectedModel", "triggerMode"], (data) => {
    if (data.geminiApiKey) {
      apiKeyInput.value = data.geminiApiKey;
      updateStatus(true);
    } else {
      updateStatus(false);
    }

    if (data.selectedModel) {
      modelSelect.value = data.selectedModel;
    }

    if (data.triggerMode) {
      triggerModeSelect.value = data.triggerMode;
    }
  });

  // Toggle API key visibility
  toggleKeyBtn.addEventListener("click", () => {
    if (apiKeyInput.type === "password") {
      apiKeyInput.type = "text";
      toggleKeyBtn.innerHTML = `
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="1" y1="1" x2="23" y2="23"></line>
          <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
        </svg>
      `;
    } else {
      apiKeyInput.type = "password";
      toggleKeyBtn.innerHTML = `
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
          <circle cx="12" cy="12" r="3"></circle>
        </svg>
      `;
    }
  });

  // Update Status Indicator
  function updateStatus(hasKey) {
    if (hasKey) {
      statusIndicator.className = "status-indicator ready";
      statusBadgeText.textContent = "Ready";
    } else {
      statusIndicator.className = "status-indicator needs-key";
      statusBadgeText.textContent = "Key Required";
    }
  }

  // Save Settings
  btnSave.addEventListener("click", () => {
    const key = apiKeyInput.value.trim();
    const model = modelSelect.value;
    const triggerMode = triggerModeSelect.value;

    chrome.storage.sync.set(
      {
        geminiApiKey: key,
        selectedModel: model,
        triggerMode: triggerMode
      },
      () => {
        updateStatus(Boolean(key));
        const originalText = btnSave.textContent;
        btnSave.textContent = "✓ Saved!";
        btnSave.style.background = "#10b981";

        setTimeout(() => {
          btnSave.textContent = originalText;
          btnSave.style.background = "";
        }, 1500);
      }
    );
  });

  // Test Key Connection
  btnTest.addEventListener("click", () => {
    const key = apiKeyInput.value.trim();
    const model = modelSelect.value;

    if (!key) {
      showTestResult(false, "Please paste an API key first.");
      return;
    }

    testSpinner.classList.add("show");
    btnTest.disabled = true;
    testResult.style.display = "none";

    chrome.runtime.sendMessage(
      {
        action: "TEST_API_KEY",
        payload: {
          apiKey: key,
          model: model
        }
      },
      (res) => {
        testSpinner.classList.remove("show");
        btnTest.disabled = false;

        if (res && res.success) {
          showTestResult(true, res.message || "Connected successfully!");
        } else {
          showTestResult(false, (res && res.message) || "Validation failed.");
        }
      }
    );
  });

  function showTestResult(isSuccess, message) {
    testResult.textContent = message;
    testResult.className = `test-result-box ${isSuccess ? "success" : "error"}`;
  }
});
