/**
 * ContextLens - Background Service Worker (Manifest V3)
 * Handles communication with Google Gemini API securely.
 */

const DEFAULT_MODEL = "gemini-1.5-flash";
const API_BASE = "https://generativelanguage.googleapis.com/v1beta/models";

// In-memory cache for fast repeat lookups during a session
const cache = new Map();
const MAX_CACHE_SIZE = 100;

function getCacheKey(term, context, model) {
  return `${model}::${term.trim().toLowerCase()}::${context.trim().slice(0, 100)}`;
}

/**
 * Handle incoming messages from content script or popup
 */
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "GET_DEFINITION") {
    handleGetDefinition(request.payload)
      .then(sendResponse)
      .catch((err) => {
        sendResponse({
          success: false,
          errorType: "INTERNAL_ERROR",
          message: err.message || "An unexpected error occurred."
        });
      });
    return true; // Keep message channel open for async response
  }

  if (request.action === "TEST_API_KEY") {
    handleTestApiKey(request.payload)
      .then(sendResponse)
      .catch((err) => {
        sendResponse({
          success: false,
          errorType: "TEST_FAILED",
          message: err.message || "Connection test failed."
        });
      });
    return true;
  }

  if (request.action === "OPEN_SETTINGS") {
    chrome.runtime.openOptionsPage();
    sendResponse({ success: true });
    return false;
  }
});

/**
 * Fetch definition or translation from Gemini API
 */
async function handleGetDefinition({ term, context }) {
  if (!term || !term.trim()) {
    return {
      success: false,
      errorType: "INVALID_INPUT",
      message: "No text was highlighted."
    };
  }

  // Retrieve stored settings
  const storage = await chrome.storage.sync.get(["geminiApiKey", "selectedModel"]);
  const apiKey = (storage.geminiApiKey || "").trim();
  const model = storage.selectedModel || DEFAULT_MODEL;

  if (!apiKey) {
    return {
      success: false,
      errorType: "NO_API_KEY",
      message: "Gemini API key is missing. Please open the ContextLens popup to set your API key."
    };
  }

  // Check cache
  const cacheKey = getCacheKey(term, context || "", model);
  if (cache.has(cacheKey)) {
    return {
      success: true,
      text: cache.get(cacheKey),
      model,
      cached: true
    };
  }

  const endpoint = `${API_BASE}/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;

  const promptText = `TARGET TERM OR PHRASE:
"${term.trim()}"

SURROUNDING PARAGRAPH CONTEXT:
"""
${(context || term).trim()}
"""

TASK:
Provide ONLY a brief, direct contextual definition or simple translation explaining what the target term means based exclusively on that specific paragraph.

STRICT INSTRUCTIONS:
- Maximum 1-2 short sentences (under 40 words total).
- Do NOT provide preambles, greetings, or meta-commentary like "In this context,", "The definition is:", or "According to the text".
- If the phrase is in another language, return the natural translation followed immediately by its contextual sense in this paragraph.
- Return only the definitive meaning.`;

  const requestBody = {
    contents: [
      {
        role: "user",
        parts: [{ text: promptText }]
      }
    ],
    systemInstruction: {
      parts: [
        {
          text: "You are a precise, minimalist contextual lexicographer and translator. Your output must strictly be only a brief contextual definition or simple translation derived solely from the provided paragraph. Be direct, authoritative, and concise. Never add introductory or conversational filler."
        }
      ]
    },
    generationConfig: {
      temperature: 0.1,
      maxOutputTokens: 120
    }
  };

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(requestBody)
    });

    const data = await response.json();

    if (!response.ok) {
      const errStatus = response.status;
      const apiMsg = data?.error?.message || response.statusText;

      if (errStatus === 400 || errStatus === 403) {
        return {
          success: false,
          errorType: "INVALID_KEY",
          message: `API Key rejected (${errStatus}): ${apiMsg}`
        };
      }

      if (errStatus === 429) {
        return {
          success: false,
          errorType: "QUOTA_EXCEEDED",
          message: "Gemini API rate limit or quota exceeded. Please wait a moment and try again."
        };
      }

      return {
        success: false,
        errorType: "API_ERROR",
        message: `Gemini API Error (${errStatus}): ${apiMsg}`
      };
    }

    const candidate = data.candidates?.[0];
    const resultText = candidate?.content?.parts?.[0]?.text?.trim();

    if (!resultText) {
      // Check for safety finish reason
      const finishReason = candidate?.finishReason;
      if (finishReason && finishReason !== "STOP") {
        return {
          success: false,
          errorType: "SAFETY_BLOCKED",
          message: `Could not define term (${finishReason}).`
        };
      }
      return {
        success: false,
        errorType: "EMPTY_RESPONSE",
        message: "Gemini returned an empty response for this context."
      };
    }

    // Save to cache
    if (cache.size >= MAX_CACHE_SIZE) {
      const oldestKey = cache.keys().next().value;
      cache.delete(oldestKey);
    }
    cache.set(cacheKey, resultText);

    return {
      success: true,
      text: resultText,
      model,
      cached: false
    };
  } catch (networkErr) {
    return {
      success: false,
      errorType: "NETWORK_ERROR",
      message: `Network failure connecting to Gemini: ${networkErr.message}`
    };
  }
}

/**
 * Live test an API key
 */
async function handleTestApiKey({ apiKey, model = DEFAULT_MODEL }) {
  if (!apiKey || !apiKey.trim()) {
    return {
      success: false,
      message: "Please enter an API key to test."
    };
  }

  const endpoint = `${API_BASE}/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey.trim())}`;
  
  const testBody = {
    contents: [
      {
        parts: [{ text: "Respond with the single word 'OK'." }]
      }
    ],
    generationConfig: {
      maxOutputTokens: 5
    }
  };

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(testBody)
    });

    const data = await response.json();

    if (!response.ok) {
      const errMsg = data?.error?.message || response.statusText;
      return {
        success: false,
        message: `Validation failed (${response.status}): ${errMsg}`
      };
    }

    return {
      success: true,
      message: `Successfully connected to Gemini API (${model})!`
    };
  } catch (err) {
    return {
      success: false,
      message: `Connection error: ${err.message}`
    };
  }
}
